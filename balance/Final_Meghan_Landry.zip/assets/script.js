
$(document).ready(function() {


	$('body').videoBG({
		id: 'videoBalance',
		position:"fixed",
		zIndex:0,
		mp4:'balance.mp4',
		ogv:'balance.mp4',
		webm:'balance.mp4',
		poster:'balance.mp4',
		opacity:1,
		fullscreen:true,
	});



})
